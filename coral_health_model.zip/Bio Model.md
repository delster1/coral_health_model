---
tags:
  - research/bio
---
# Overview
Model to detect or classify coral health regions from only a segmented image of coral, with the supervision coming from partial region annotations during training.

During **inference**, model only sees the segmented image of coral and outputs either:
- Classification per-pixel (segmentation)
- Classification for entire coral
## Training Data
	Adding region information in training to help Model identify locations
1. Segmented Coral Image
2. Mask over a specific region of the image - highlighting where we know what is happening
3. A **label** for the masked region - identifying bleached, healing, or dead.

# Segmentation Model
	image -> segmentation mask
**input**: 
- segmented coral image
**output**: 
- *sparse label mask* only containing labels for regions
	- everything else marked unknown
**alternative output:** 
- label mask only identifying regions where it suspects either bleached, dead, etc. 

this is **weakly supervised semantic segmentation**
### Semantic Segmentation Model
	model built for segmentation by accounting for parts of an image
U-Net - lightweight, works on small data
DeepLabV3+ - more powerfil
SegFormer - state of the art
SAM - Cool and uses extra input data

### Loss Function
Need a loss function that supports ignored regions (research!)
- Pytorch - **CrossEntropyLoss** with `ignore_index = 255`
- TensorFlow/Keras - apply mask to the loss, computing loss for known pixels
**loss only calculated in areas where coral is filled**

# Classification Model - Whole Coral
**input:** segmented coral image
**output:** classification of coral as either bleached, healing, dead, etc.

Same training data as before! - the region information in the training data should inform the classification model's choice

# Classification Model - Segmented Region
	depending on the success of the segmentation model, we could train something to classify a region that it found as healthy, ...,

**input**: 
- segmented output from segmentation model
- suspected region of impact
**output:**
- 

### CNN Classifier Network
EfficientNet, ResNet, etc.
- see code for ML pin detection

